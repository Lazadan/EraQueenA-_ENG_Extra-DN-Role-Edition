# EraQueenA+_ENG_Extra-DN-Role-Edition
This translation has been translated and modified from the Chinese version EraQueenA+人外拓展版 of November 2021

For code learning and internal communication between enthusiasts only


This modified version is intended to add roles in DeathNote
This game contains a large number of 18+elements, including various physical injuries, No-con, drug use, etc
Please ensure that you can accept the above content before playing the game


Well, if you understand the above and still choose to continue, just enjoy your journey~


Translated/Extra mod made by Lazadan 4/1/2023
